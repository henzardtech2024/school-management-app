package com.technovate.school_management.entity.enums;

public enum GradeOption {
    A,
    B,
    C,
    D,
    E,
    F
}
